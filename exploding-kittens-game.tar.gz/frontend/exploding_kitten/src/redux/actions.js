import axios from 'axios';


export const setUsername = (username) => ({
  type: 'SET_USERNAME',
  payload: username
});

export const startGameSuccess = () => ({
  type: 'START_GAME_SUCCESS'
});

export const drawCardSuccess = (deck, gameWon) => ({
  type: 'DRAW_CARD_SUCCESS',
  payload: { deck, gameWon }
});

export const saveGameSuccess = () => ({
  type: 'SAVE_GAME_SUCCESS'
});

export const fetchLeaderboardSuccess = (leaderboard) => ({
  type: 'FETCH_LEADERBOARD_SUCCESS',
  payload: leaderboard
});

export const startGame = (username) => async (dispatch) => {
  try {
    await axios.post('http://127.0.0.1:5000/start-game', { username });
    dispatch(startGameSuccess());
  } catch (error) {
    console.error(error);
  }
};

export const drawCard = (deck, username) => async (dispatch) => {
  try {
    const response = await axios.post('http://127.0.0.1:5000/draw-card', { deck, username });
    const { deck: updatedDeck, gameWon } = response.data;
    dispatch(drawCardSuccess(updatedDeck, gameWon));
  } catch (error) {
    console.error(error);
  }
};

export const saveGame = (username, deck) => async (dispatch) => {
  try {
    await axios.post('http://127.0.0.1:5000/save-game', { username, deck });
    dispatch(saveGameSuccess());
  } catch (error) {
    console.error(error);
  }
};

export const fetchLeaderboard = () => async (dispatch) => {
  try {
    const response = await axios.get('http://127.0.0.1:5000/leaderboard');
    const leaderboard = response.data;
    dispatch(fetchLeaderboardSuccess(leaderboard));
  } catch (error) {
    console.error(error);
  }
};
