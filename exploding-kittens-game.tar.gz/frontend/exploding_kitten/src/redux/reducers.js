const initialState = {
    username: 'yash',
    deck: [],
    gameWon: false,
    leaderboard: []
  
}
  
  const gameReducer = (state = initialState, action) => {
    switch (action.type) {
      case 'SET_USERNAME':
        return { ...state, username: action.payload };
  
      case 'START_GAME_SUCCESS':
        return { ...state, deck: [], gameWon: false };
  
      case 'DRAW_CARD_SUCCESS':
        return {
          ...state,
          deck: action.payload.deck,
          gameWon: action.payload.gameWon
        };
  
      case 'SAVE_GAME_SUCCESS':
        return state; // No specific state change for saving game
  
      case 'FETCH_LEADERBOARD_SUCCESS':
        return { ...state, leaderboard: action.payload };
  
      default:
        return state;
    }
  };
  
  export default gameReducer;
  