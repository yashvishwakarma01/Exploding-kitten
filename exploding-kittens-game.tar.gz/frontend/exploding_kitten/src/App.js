import React,{useEffect} from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  startGame,
  drawCard,
  saveGame,
  fetchLeaderboard,
  setUsername,
} from './redux/actions';

const App = () => {
  const dispatch = useDispatch();
  // const { username, deck, gameWon, leaderboard } = useSelector((state) => state.gameReducer|| {username:"", deck:[], gameWon:false,leaderboard: []});
  const { username, deck, gameWon, leaderboard } = useSelector((state) => state);
  console.log(username,deck,gameWon,leaderboard)
 

  useEffect(() => {
  
    dispatch(fetchLeaderboard());

  }
  , [dispatch]
  );

  const handleStartGame = () => {
    dispatch(startGame(username));
  };

  const handleDrawCard = () => {
    dispatch(drawCard(deck, username));
  };

  const handleSaveGame = () => {
    dispatch(saveGame(username, deck));
  
  };

  return (
    <div>
      <h1>Exploding Kittens Game</h1>
      <input
        type="text"
        placeholder="Enter your username"
        value={username}
        onChange={(e) => dispatch(setUsername(e.target.value))
        } 
      />
      <button onClick={handleStartGame}>Start Game</button>
      <button onClick={handleDrawCard}>Draw Card</button>
      <button onClick={handleSaveGame}>Save Game</button>

      <div>
        <h2>Leaderboard</h2>
        <ul>
          {leaderboard.map((user) => (
            <li key={user.username}>{`${user.username}: ${user.points} points`}</li>
          ))}
        </ul>
      </div>

      <div>
        {gameWon && <p style={{color:'red',fontSize:20}}>Congratulations! You won the game!</p>}
      </div>
    </div>
  );
};

export default App;
